import * as Yup from "yup";

export const validationSchema = Yup.object({
  Username: Yup.string()
      .max(120, "Must be 120 characters or less")
      .required("This field is required")
      .email('Invalid Email'),
    Password: Yup.string()
      .max(255, "Must be 255 characters or less")
      .required("This field is required"),
  });
