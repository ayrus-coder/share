import * as React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert,
  Card,
  CardContent,
  Typography,
  CircularProgress
} from "@mui/material";
import { Formik, Form } from "formik";

// files import
import { validationSchema } from './validationSchema';
import Controls from "../../components/Controls";
import useApi from '../../hooks/useApiHook';
import { useStyles } from './loginStyle';
import { formikStyles } from './loginStyle';

export const Login = () => {
  let navigate = useNavigate();
  const classes = useStyles();

  // useState for request response, error and loading
  const [response, setResponse] = useState(null);
  const [loading, setloading] = useState(false);
  const [errorMssg, seterrorMssg] = useState(null);

  // calling fetchdata from useapi
  const [fetchdata] = useApi();

  // function to get response 
  const getresponse = (response) => {

    let data = response['data']
    if (response['status'] = 200) {
      localStorage.setItem('token', data['access_token']);
    }
    setResponse(response['message']);
    seterrorMssg(null);
    navigate('/dashboard/viewcanvas');
  }

  // function to get error 
  const geterror = (err) => {

    seterrorMssg(err.response.data.error);
  }

  // function to get loading time 
  const getloading = (data) => {

    setloading(data);
  }

  const loginHandle = (username, password) => {

    setloading(true);
    // fetchdata function called with parameters method, url, body to integrate with api
    // getrespone, geterror, getloading function are used to take responses, error, loading from the request
    fetchdata("user/login/",
      "POST", JSON.stringify({
        "username": username,
        "password": password
      }), null, getresponse, geterror, getloading, false);

  }

  return (
    <div style={{
      backgroundImage: `url(${process.env.PUBLIC_URL + '/Login.png'})`,
      backgroundSize: 'cover',
      width: '100vw',
      height: '100vh'

    }}>
      <div className={classes.login_digiprint}>
        <div className={classes.login_digiprint_heading}>Smart Canvas</div>
      </div>
      {/* formik start */}
      <Formik
        initialValues={{ Username: "", Password: "" }}
        validationSchema={validationSchema}
        onSubmit={(values, { setSubmitting }) => {

          loginHandle(values['Username'], values['Password']);
        }}>
        {({ errors, touched }) => (
          <Form className={classes.login_form}>
            <Card className={classes.login_Card}>
              <CardContent sx={{ margin: '32px' }}>

                <Typography className={classes.login_heading}>
                  Login
                </Typography>

                <Typography className={classes.login_subheading}>
                  Log In to start visualizing and interacting with clients on their insurance programs.
                </Typography>

                {errorMssg && <Alert className={classes.login_responseError} severity="error">{errorMssg}</Alert>}

                <Typography variant='body2' component='div'>
                  <Controls.TextField
                    name='Username'
                    variant='outlined'
                    label='Email'
                    errors={errors}
                    touched={touched}
                    sx={formikStyles.login_email}
                  />
                  <Controls.PasswordTextField
                    name='Password'
                    variant='outlined'
                    label='Password'
                    errors={errors}
                    touched={touched}
                    sx={formikStyles.login_email} />
                </Typography>

                <Controls.Button
                  variant="contained" fullWidth
                  sx={formikStyles.login_button}
                  type='submit'>
                  {loading ? <CircularProgress sx={{ color: 'white' }} /> : <Typography>Log In</Typography>}
                </Controls.Button>
              </CardContent>
            </Card >
          </Form>
        )}
      </Formik>
      {/* formik end */}
    </div >
  );
};

