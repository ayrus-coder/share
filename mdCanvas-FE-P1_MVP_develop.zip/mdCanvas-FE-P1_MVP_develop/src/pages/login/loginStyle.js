import { makeStyles } from "@mui/styles";

export const useStyles = makeStyles({
    login_responseError: {
        fontWeight: '400',
        fontSize: '12px',
        marginTop: '15px',
        alignItems: 'center'
    },
    login_form: {
        position: 'absolute',
        marginTop: '20.938em',
        marginLeft: '12.375em'
    },
    login_Card: {
        width: '26em',
        minHeight: '24.688em'
    },
    login_heading: {
        fontSize: '1.875em !important', fontWeight: '37.5em',
        fontFamily: 'Open Sans', fontStyle: 'normal',
        color: '#1F1F1F', textAlign: 'center'
    },
    login_subheading: {
        fontSize: '0.875em !important', fontWeight: '25em',
        fontFamily: 'Open Sans', fontStyle: 'normal',
        color: '#8C8C8C', textAlign: 'center', marginTop: '0.5em !important'
    },
    login_digiprint: {
        position: 'absolute',
        marginTop: '15.625em',
        width: '100%'
    },
    login_digiprint_heading: {
        marginLeft: '198px',
        width: '416px',
        fontWeight: '37.5em',
        fontSize: '2.5em',
        color: '#FFFFFF',
        display: 'flex',
        justifyContent: 'center'
    }
});

export const formikStyles = {
    login_email: {
        marginTop: '2em'
    },
    login_password: {
        marginTop: '1em'
    },
    login_button: {
        backgroundColor: '#007680',
        border: '0.063em solid #007680',
        borderRadius: '0.125em',
        marginTop: '2em'
    }
}