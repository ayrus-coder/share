import { makeStyles } from "@mui/styles";

export const useStyles = makeStyles({
    dialogBox: {
        padding: '100px !important'
    }
});
