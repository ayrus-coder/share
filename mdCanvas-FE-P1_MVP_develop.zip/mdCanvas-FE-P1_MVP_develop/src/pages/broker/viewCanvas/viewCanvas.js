import * as React from 'react';
import PropTypes from 'prop-types';
import {
    Box, styled,
    CssBaseline, Typography, Button, Dialog,
    DialogTitle, DialogContent, DialogActions, IconButton
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useEffect, useState } from 'react';
import { useStyles } from './viewCanvasStyle';
import Header from '../../../components/Header/Header';

const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),

    ...theme.mixins.toolbar,
}));

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
    '& .MuiPaper-root': {
        backgroundImage: `url(${process.env.PUBLIC_URL + '/landingBackground.png'})`,
        height: '565px',
        maxWidth: '896px !important'
    },
}));

function BootstrapDialogTitle(props) {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
}

BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
};
export default function ViewCanvas() {
    const classes = useStyles();
    const [open, setOpen] = useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    useEffect(() => {
        handleClickOpen();
    }, [])

    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <Header />
            <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                <DrawerHeader />
                <BootstrapDialog
                    onClose={handleClose}
                    aria-labelledby="customized-dialog-title"
                    open={open}>
                    <BootstrapDialogTitle
                        id="customized-dialog-title"
                        onClose={handleClose}>

                    </BootstrapDialogTitle>
                    <DialogContent >

                        <Typography sx={{ padding: 5 }}>
                            <Typography sx={{
                                marginBottom: '64px', display: 'flex',
                                justifyContent: 'center', color: '#004F59', fontWeight: '600',
                                fontSize: '38px'
                            }}>
                                How to use
                            </Typography>
                            <Typography sx={{
                                fontWeight: '600',
                                fontWize: '20px',
                                color: '#595959'
                            }}>
                                "Welcome!
                                Smart Canvas enables its users to create
                                Canvases for P&C insurances to be shared
                                with the Broker Organizations' clients.
                                This easy to use tool not only allows
                                users to create canvases but also
                                provides the provision of versioning,
                                saving, downloading and sharing them
                                with the client through the tool itself."
                            </Typography>

                        </Typography>
                    </DialogContent>
                    <DialogActions sx={{ justifyContent: 'center', marginBottom: '20px' }}>
                        <Button onClick={handleClose} sx={{
                            background: '#007680',
                            border: '1px solid #007680',
                            borderRadius: '2px',
                            padding: '4px 40px',
                            display: 'flex',

                            justifyContent: 'center',
                            fontWeight: '700',
                            fontSize: '14px',
                            color: '#FFFFFF'
                        }}>
                            Let’s get started
                        </Button>
                    </DialogActions>
                </BootstrapDialog>

                <h1>
                    View Canvas
                </h1>
            </Box>
        </Box >
    );
}
