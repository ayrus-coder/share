import { flexbox } from "@chakra-ui/react";
import { makeStyles } from "@mui/styles";

export const useStyles = makeStyles({
    inputBlock: {
        display: 'flex',
        marginTop: '30px',
        justifyContent: 'space-between'
    },
    heading: {
        color: '#8C8C8C',
        fontWeight: '600',
        fontSize: '20px',
        marginTop: '25px',
        marginLeft: '32px'
    },
    accountInput: {
        fontWeight: '400',
        fontSize: '14px',
        width: '242px;',
        marginLeft: '73px !important'
    },
    accountInputLabel: {
        color: 'red !important'
    },
    inputSearch: {
        marginRight: '55px !important'
    },
    tableBackground: {
        backgroundColor: '#eefdff',
        height: '100%',
        marginTop: '33px'
    },
    noOfResults: {
        paddingTop: '10px',
        paddingLeft: '72px'
    },
    resultHeading: {
        fontWeight: '400',
        fontSize: '14px',
        color: 'rgba(0, 0, 0, 0.45)'
    },
    noDataImageBlock: {
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center'
    },
    noDataImage: {
        height: '150px',
        width: '150px'
    },
    noDataImageText: {
        width: '200px',
        textAlign: 'center'
    },
    progressLoader: {
        display: 'flex !important',
        justifyContent: 'center !important'
    }


});

