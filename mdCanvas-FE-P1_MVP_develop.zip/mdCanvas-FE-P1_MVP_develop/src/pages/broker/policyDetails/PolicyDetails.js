import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import { AgGridReact } from 'ag-grid-react';
import TextField from '@mui/material/TextField';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { CircularProgress, FormControl, IconButton, InputAdornment, InputLabel, MenuItem, Select } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
// other file imports
import Header from '../../../components/Header/Header';
import { useStyles } from './PolicyDetailsStyle';
import './PolicyDetails.css';
import useApi from '../../../hooks/useApiHook';


const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
}));

export default function PolicyDetails() {
    // custom hook for api
    const [fetchdata] = useApi();
    // classes to give css classes
    const classes = useStyles();
    // reference to the table
    const gridRef = useRef();

    // Show Table usestate 
    // usestate for manage of table columns and row data
    const [rowData, setRowData] = useState([]);
    const [columnDefs, setColumnsDefs] = useState([]);

    // usestate for select account drop down
    const [accountValue, setAccountValue] = useState('');
    // usestate for global search over table
    const [globalsearch, setGlobalsearch] = useState('');

    // number of policies for that account
    const [noOfPolicies, setNoOfPolicies] = useState(0);

    // Account api
    // usestate to handle response, error, loading for account api
    const [responseAccount, setResponseAccount] = useState(null);
    const [loadingAccount, setLoadingAccount] = useState(true);
    const [errorMssgAccount, setErrorMssgAccount] = useState(null);

    // Table api
    // usestate to handle response, error, loading for table api
    const [responseTable, setResponseTable] = useState(null);
    const [loadingTable, setLoadingTable] = useState(false);
    const [errorMssgTable, setErrorMssgTable] = useState(null);

    // Default col properties
    const defaultColDef = {
        sortable: true, filter: true
    }

    // handle function for global search
    const handleinputsearch = (e) => {
        gridRef.current.api.setQuickFilter(
            e.target.value
        );
        setGlobalsearch(e.target.value);
    }

    // handle for account select
    const setAccountHandle = (event) => {
        let value = event.target.value;
        setAccountValue(value);

        setLoadingTable(true);
        // call setTableData for this account
        setTableData(value);
    }

    //  get account response from api
    const getAccountResponse = (data) => {
        setResponseAccount(data['data']);
    }

    //  get account error from api
    const getAccountError = (err) => {

    }

    //  get account loading from api
    const getAccountLoading = (data) => {
        setLoadingAccount(data);
    }

    //  get table response from api and setting data into table
    const getTableResponse = (data) => {
        let response = data['data']
        let columnDef = [];
        setNoOfPolicies(response.length);
        if (response.length > 0) {
            columnDef.push({
                field: "id",
                filterParams: {
                    buttons: ['clear', 'apply'],
                },
                resizable: true
            })
        }
        let key;
        const new_data = response.map((policy, ind) => {

            key = policy.id

            let policy_attr_array = policy.attributes.map(attribute => {
                if (ind === 0) {
                    columnDef.push({
                        field: attribute['attribute_name'],
                        filterParams: {
                            buttons: ['clear', 'apply'],
                        },
                        resizable: true
                    })
                }

                return {
                    [attribute['attribute_name']]: (attribute['value'] ? attribute['value'] : 'NA')
                }
            })

            let attribute_value_object = {}
            for (let policy_attr of policy_attr_array) {
                Object.keys(policy_attr).map(attribute_name => {
                    attribute_value_object[attribute_name] = policy_attr[attribute_name]
                })

            }
            let obj = {
                id: key,
                ...attribute_value_object
            }
            return obj;

        })

        setRowData(new_data);
        setColumnsDefs(columnDef);
    }

    //  get table error from api
    const getTableError = (err) => {
    }

    //  get table loading from api
    const getTableLoading = (data) => {
        setLoadingTable(data);
    }

    // call table data for the selected account
    const setTableData = (id) => {

        fetchdata(`core/policy?account__id=${id}`,
            "GET", null, null, getTableResponse,
            getTableError, getTableLoading, true);

    }

    useEffect(() => {

        // below commented code need for future use

        // if (gridRef) {
        // gridRef.current.api.sizeColumnsToFit({
        //     defaultMinWidth: 1000
        // });
        // }

        // Get data for account select option
        fetchdata("core/accounts",
            "GET", null, null, getAccountResponse,
            getAccountError, getAccountLoading, true);
    }, [])

    return (
        <Box sx={{ display: 'flex', height: '100%' }}>
            <CssBaseline />
            <Header />
            <Box
                sx={{ flexGrow: 1 }}>
                <DrawerHeader />

                <div className={classes.heading}>
                    <span>
                        Policy Details
                    </span>
                </div>

                {/* This div contains global search and account select */}
                <div className={classes.inputBlock}>
                    <FormControl className={classes.accountInput} size="small">

                        <InputLabel id="demo-simple-select-label">Select Account
                        </InputLabel>
                        <Select
                            id="demo-simple-select"
                            value={accountValue}
                            label="Select Account"
                            onChange={(e) => setAccountHandle(e)}
                        >
                            {loadingAccount && <div className={classes.progressLoader}>
                                <CircularProgress />
                            </div>}

                            {responseAccount?.map((ele) => (
                                <MenuItem key={ele['id']} value={ele['id']}>
                                    {ele['account_name']}
                                </MenuItem>
                            ))}

                        </Select>

                    </FormControl>

                    <TextField id="outlined-basic" label="Input search text"
                        value={globalsearch}
                        className={classes.inputSearch}
                        onChange={handleinputsearch}
                        variant="outlined"
                        size="small"
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        aria-label="toggle password visibility">
                                        <SearchIcon />
                                    </IconButton>
                                </InputAdornment>
                            )
                        }}
                    />
                </div>

                {/* This div contains table */}
                <div className={classes.tableBackground}
                >
                    <div className={classes.noOfResults}>
                        <span className={classes.resultHeading}>
                            {noOfPolicies + ' results'}
                        </span>
                    </div>

                    <div
                        className="ag-theme-alpine"
                        style={{
                            width: '100%', minHeight: 500,
                            paddingTop: '12px', paddingLeft: '72px', paddingRight: '40px'
                        }}
                    >
                        <AgGridReact
                            ref={gridRef}
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            animateRows={true}
                            detailRowAutoHeight={true}
                            pagination={true}
                            paginationPageSize={25}
                        >
                        </AgGridReact>

                        {loadingTable && <div className={classes.progressLoader}>
                            <CircularProgress />
                        </div>}
                    </div>

                    {noOfPolicies === 0 && <div className={classes.noDataImageBlock}>
                        <img className={classes.noDataImage}
                            src={'/Empty_icon.svg'}
                            loading="lazy"
                        />
                        <span className={classes.noDataImageText}>
                            No Policy to show, <br></br>
                            Please select the account.</span>
                    </div>}
                </div>

            </Box>
        </Box>
    );
}
