import { Login } from "./pages/login/Login";
import ViewCanvas from "./pages/broker/viewCanvas/viewCanvas";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NewCanvas from "./pages/broker/newCanvas/NewCanvas";
import PolicyDetails from "./pages/broker/policyDetails/PolicyDetails";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/*" element={<Login />} />
        <Route path="/dashboard/viewcanvas" element={<ViewCanvas />} />
        <Route path="/dashboard/newcanvas" element={<NewCanvas />} />
        <Route path="/dashboard/policydetails" element={<PolicyDetails />} />
      </Routes>
    </Router>
  );
}

export default App;
