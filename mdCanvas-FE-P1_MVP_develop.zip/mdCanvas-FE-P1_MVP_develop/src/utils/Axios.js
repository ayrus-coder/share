import axios from "axios";

const Axios = axios.create({
    baseURL: "https://some-baths-shout-49-37-170-35.loca.lt",
});

export default Axios;