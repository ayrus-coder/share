import { makeStyles } from "@mui/styles";

export const useStyles = makeStyles({
    toolbarBlock: { backgroundColor: '#1F1F1F' },
    menuButton: {
        color: '#6FC2B4 !important'
    },
    header: {
        display: 'flex',
        flexDirection: 'row-reverse',
        width: '100%',
        alignItems: 'center'
    },
    avatar: { color: '#9DD4CF', fontSize: '40px' },
    headerHeading: {
        marginRight: '30px'
    },
    drawerHeader: { color: '#6FC2B4 !important' },
    sidenav: {
        display: 'block'
    },
    sidenavItems: {
        minHeight: 48,
        px: 2.5
    },
    sidenavItemsIcons: {
        minWidth: 0,
        justifyContent: 'center',
        color: '#6FC2B4 !important'
    }
});
