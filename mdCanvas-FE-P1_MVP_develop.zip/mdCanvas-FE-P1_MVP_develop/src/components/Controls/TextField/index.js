import React from "react";
import { TextField } from "@mui/material";
import { ErrorMessage, Field, useField, getIn } from "formik";
import { makeStyles } from "@mui/styles";

// check for error on the input
// if return true show red outlined
function checkError(errors, touched, fieldName) {
  if (getIn(errors, fieldName) && getIn(touched, fieldName)) {
    return true
  }
}

const useStyles = makeStyles({
  errorText: {
    color: "#f44336",
    paddingLeft: "10px",
    fontSize: "12px"
  }
});

const TextFieldWrapper = (props) => {
  const { name, label, ...otherProps } = props;
  const configTextfield = {
    ...otherProps,
    fullWidth: true
  };

  const [field, meta] = useField(props);
  const classes = useStyles();
  return (
    <>
      <Field as={TextField} label={label}
        error={checkError(props.errors, props.touched, props.name)}

        name={name} {...configTextfield} />
      <ErrorMessage name={name}>
        {(msg) => <p className={classes.errorText}>{msg}</p>}
      </ErrorMessage>
    </>
  );
};

export default TextFieldWrapper;
