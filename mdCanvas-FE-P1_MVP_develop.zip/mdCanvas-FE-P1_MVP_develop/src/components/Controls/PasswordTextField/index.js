import React, { useState } from "react";
import { TextField } from "@mui/material";
import { ErrorMessage, Field, useField, getIn } from "formik";
import { makeStyles } from "@mui/styles";

import { InputAdornment, IconButton } from "@mui/material";
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

function checkError(errors, touched, fieldName) {
  if (getIn(errors, fieldName) && getIn(touched, fieldName)) {
    return true
  }
}

const useStyles = makeStyles({
  errorText: {
    color: "#f44336",
    paddingLeft: "10px",
    fontSize: "12px"
  }
});

const PasswordTextFieldWrapper = (props) => {
  const { name, label, ...otherProps } = props;
  const configTextfield = {
    ...otherProps,
    fullWidth: true
  };

  const [field, meta] = useField(props);
  const classes = useStyles();

  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => setShowPassword(!showPassword);


  return (
    <>
      <Field as={TextField} label={label}

        error={checkError(props.errors, props.touched, props.name)}
        type={showPassword ? "text" : "password"}
        name={name} {...configTextfield}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}

              >
                {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
              </IconButton>
            </InputAdornment>
          )
        }} />
      <ErrorMessage name={name}>
        {(msg) => <p className={classes.errorText}>{msg}</p>}
      </ErrorMessage>
    </>
  );
};

export default PasswordTextFieldWrapper;
