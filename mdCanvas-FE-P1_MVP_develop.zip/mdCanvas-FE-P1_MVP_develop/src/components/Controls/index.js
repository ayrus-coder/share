import Button from "./Button";
import TextField from "./TextField/index";
import PasswordTextField from "./PasswordTextField";
const Controls = {
  Button,
  TextField,
  PasswordTextField
};

export default Controls;
