import Axios from "../utils/Axios";
const useApi = () => {

  const fetchData = (url, method, body = null,
    headers = null, setResponse, seterrorMssg, setloading, flag) => {

    let token = localStorage.getItem('token');
    let axios;
    if (flag) {
      axios = Axios({
        method: method,
        url: url,
        data: JSON.parse(body),
        // headers: JSON.parse(headers) -> need to keep for future
        headers: {
          'Bypass-Tunnel-Reminder': 'null',
          'Authorization': `Bearer ${token}`
        }
      })
    }
    else {
      axios = Axios({
        method: method,
        url: url,
        data: JSON.parse(body),
        // headers: JSON.parse(headers) -> need to keep for future
        headers: { 'Bypass-Tunnel-Reminder': 'null' }
      })
    }

    axios
      .then((res) => {
        setResponse(res.data);
      })
      .catch((err) => {
        seterrorMssg(err);
      })
      .finally(() => {
        setloading(false);
      });

  };

  return [fetchData];
};

export default useApi;