# Canvas - FE
This is the codebase for React app pertaining to the Mudmap project
