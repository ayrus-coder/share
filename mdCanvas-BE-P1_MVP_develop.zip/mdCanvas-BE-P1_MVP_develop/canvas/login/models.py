import uuid
import logging
from django.contrib.auth.models import AbstractUser
from django.db import models

from login.constants import UserType

logger = logging.getLogger(__name__)


class Role(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user_type = models.CharField(max_length=20)
    role = models.CharField(max_length=20, choices=UserType.choices, default=UserType.BROKER, null=False)
    default_access_list = models.JSONField(null=True, blank=True)

    def save(self, *args, **kwargs):
        self.user_type = UserType(self.role).label
        super(Role, self).save(*args, **kwargs)

    def __str__(self):
        return self.role

    class Meta:
        db_table = 'MD_ROLE'


class User(AbstractUser):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    username = models.CharField(max_length=120, null=False, unique=True)
    email = models.EmailField(max_length=120, null=False, unique=True)
    password = models.CharField(max_length=255, null=False)
    role = models.ForeignKey(Role, on_delete=models.DO_NOTHING, blank=True, null=True)
    access_override_list = models.JSONField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.is_superuser and not User.objects.filter(email=self.email).exists():
            self.set_password(self.password)
        super(User, self).save(*args, **kwargs)
        logger.info("User saved!")

    def __str__(self):
        return self.username

    class Meta:
        db_table = 'MD_USER'
