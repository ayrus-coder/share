from django.db import models
from django.utils.translation import gettext_lazy as _


class UserType(models.TextChoices):
    BROKER = 'BR', _('Broker')
    RISK_MANAGER = 'RM', _('Risk Manager')
    ADMIN = 'SYS_ADMIN', _('Admin')


class AccessCode(models.TextChoices):
    CREATE = 'CREATE', _('Create')
    READ = 'READ', _('Read')
    UPDATE = 'UPDATE', _('Update')
    DELETE = 'DELETE', _('Delete')
