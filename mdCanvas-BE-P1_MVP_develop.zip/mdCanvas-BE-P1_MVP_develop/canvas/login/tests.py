from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from login.models import User


class UserLoginTests(APITestCase):
    def setUp(self):
        self.user = User(username='test', email='test@deloitte.com', password='test')
        self.user.save()

    def test_login(self):
        """
        Ensure we can login using username and password for a user.
        """
        url = reverse('token_obtain_pair')
        data = {
            'username': 'test@deloitte.com',
            'password': 'test'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.data['message'], 'Success')
        self.assertEqual(response.data['status'], status.HTTP_200_OK)

    def test_login_wrong_credentials(self):
        """
        Ensure we get an error if we login using wrong credentials for a user.
        """
        url = reverse('token_obtain_pair')
        data = {
            'username': 'test@deloitte.com',
            'password': 'test2'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.data['message'], 'Failure')
        self.assertEqual(response.data['status'], str(status.HTTP_401_UNAUTHORIZED))

    def test_refresh(self):
        """
        Ensure we can refresh the access token using refresh token for a user.
        """
        login_url = reverse('token_obtain_pair')
        login_data = {
            'username': 'test@deloitte.com',
            'password': 'test'
        }
        login_response = self.client.post(login_url, login_data, format='json')

        refresh_token = login_response.data['data']['refresh_token']
        refresh_data = {
            'refresh': refresh_token
        }

        refresh_url = reverse('token_refresh')
        refresh_response = self.client.post(refresh_url, refresh_data, format='json')
        self.assertEqual(refresh_response.data['message'], 'Success')
        self.assertEqual(refresh_response.data['status'], status.HTTP_200_OK)

    def test_wrong_refresh_token(self):
        """
        Ensure we get an error if we refresh the access token using wrong refresh token for a user.
        """
        login_url = reverse('token_obtain_pair')
        login_data = {
            'username': 'test@deloitte.com',
            'password': 'test'
        }
        login_response = self.client.post(login_url, login_data, format='json')

        refresh_token = login_response.data['data']['refresh_token'] + 'wrong'
        refresh_data = {
            'refresh': refresh_token
        }

        refresh_url = reverse('token_refresh')
        refresh_response = self.client.post(refresh_url, refresh_data, format='json')
        self.assertEqual(refresh_response.data['message'], 'Failure')
        self.assertEqual(refresh_response.data['status'], status.HTTP_400_BAD_REQUEST)

