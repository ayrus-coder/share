from django.utils.module_loading import import_string
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer, TokenRefreshSerializer

from login.models import User


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    default_error_messages = {
        'no_active_account': {
            'error': 'Incorrect Email ID or Password',
            'status': 401,
            'message': 'Failure'
        }
    }

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['username'] = user.username
        token['email'] = user.email
        if user.role:
            token['role'] = user.role.role
            token['user_type'] = user.role.user_type
        return token

    def validate(self, attrs):
        credentials = {
            'username': '',
            'password': attrs.get("password")
        }
        user_obj = User.objects.filter(email=attrs.get("username")).first() or User.objects.filter(
            username=attrs.get("username")).first()
        if user_obj:
            credentials['username'] = user_obj.username

        data = super().validate(credentials)

        result = dict()
        result['refresh_token'] = data['refresh']
        result['access_token'] = data['access']
        del data['refresh']
        del data['access']

        data['message'] = 'Success'
        data['status'] = 200
        data['data'] = result

        return data


class CustomTokenRefreshSerializer(TokenRefreshSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['username'] = user.username
        token['email'] = user.email
        if user.role:
            token['role'] = user.role.role
            token['user_type'] = user.role.user_type
        return token

    def validate(self, attrs):
        token_backend = import_string(
                "rest_framework_simplejwt.state.token_backend"
            )
        try:
            payload = token_backend.decode(attrs["refresh"], verify=True)
        except:
            data = dict()
            data['error'] = 'Token is invalid or expired'
            data['status'] = 400
            data['message'] = 'Failure'
            return data

        data = super().validate(attrs)

        result = dict()
        result['refresh_token'] = data['refresh']
        result['access_token'] = data['access']
        del data['refresh']
        del data['access']

        data['message'] = 'Success'
        data['status'] = 200
        data['data'] = result

        return data
