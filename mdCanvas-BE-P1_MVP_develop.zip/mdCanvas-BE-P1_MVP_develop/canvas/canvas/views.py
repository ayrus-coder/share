from time import sleep

from django.contrib import messages
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .forms import UploadFileForm
from canvas.utils import handle_uploaded_file

import logging
logger = logging.getLogger(__name__)


def upload_file(request):
    """
    view for upload file
    """
    try:
        if request.method == 'POST':
            form = UploadFileForm(request.POST, request.FILES)
            if form.is_valid():
                handle_uploaded_file(request.FILES['file'])
                logger.info('Data uploaded successfully.')
                messages.success(request, 'Data uploaded successfully.')
                return render(request, 'upload/upload.html', {'form': UploadFileForm(request.GET)})
            else:
                logger.info('Invalid form submission.')
                messages.error(request, 'Invalid form submission.')
                messages.error(request, form.errors)
        else:
            form = UploadFileForm()
        return render(request, 'upload/upload.html', {'form': form})
    except Exception as e:
        logger.exception('Exception found while uploading file')
        messages.error(request, 'Invalid form submission.')
        return render(request, 'upload/upload.html', {'form': UploadFileForm(request.GET)})
