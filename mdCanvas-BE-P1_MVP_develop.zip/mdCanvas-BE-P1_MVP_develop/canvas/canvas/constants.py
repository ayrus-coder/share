from core.constants import DisplayMetric, AttributeType

dummy_account_name = 'Walmart1'
policy_column_names = ['Policy Number', 'Policy Type', 'Coverage Layer', 'Issuing Carrier']
policy_column_names_database = ['policy_name', 'policy_type', 'coverage_layer', 'carrier_name']
policy_attribute_types = [
    {
        'attribute_name': 'First Named Insured',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Policy Number',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Policy Name',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Policy Term',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Line of Coverage',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Coverage',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Coverage Name',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Policy Description',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Carrier',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Carrier Participation Per',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.PERCENTAGE
    },
    {
        'attribute_name': 'Policy Limit',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Coverage Layer',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Sub-Limits',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'TIV',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Deductible',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'SIR',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Premium',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Taxes, Fees, and Surcharges',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Policy Cost',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Carrier Capacity',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'AM Best Rating',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Intermediary',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Effective Date',
        'attribute_type': AttributeType.DATE,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Expiration Date',
        'attribute_type': AttributeType.DATE,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Attachment Point',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Policy Limit(s)',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Premium Share',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Program Type',
        'attribute_type': AttributeType.TEXT,
        'display_metric': DisplayMetric.TEXT
    },
    {
        'attribute_name': 'Lower Limit',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    {
        'attribute_name': 'Upper Limit',
        'attribute_type': AttributeType.NUMBER,
        'display_metric': DisplayMetric.CURR
    },
    
]
