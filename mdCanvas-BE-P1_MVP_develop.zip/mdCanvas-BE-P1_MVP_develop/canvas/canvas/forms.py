from django import forms
from rest_framework.exceptions import ValidationError


def validate_file_extension(value):
    if value.content_type not in ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/csv']:
        raise ValidationError(u'Error message')


class UploadFileForm(forms.Form):
    file = forms.FileField(label='File', validators=[validate_file_extension])
