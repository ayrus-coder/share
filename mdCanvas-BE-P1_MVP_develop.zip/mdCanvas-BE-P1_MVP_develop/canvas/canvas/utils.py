import logging
import csv
from datetime import datetime
from openpyxl import load_workbook
from django.core.files.storage import default_storage
from canvas.constants import dummy_account_name, policy_column_names, policy_attribute_types, policy_column_names_database
from canvas.settings import MEDIA_ROOT
from core.constants import PolicyType
from core.models import PolicyAttributeType, Policy, PolicyAttribute, Account, Organization, Contact
from login.models import User, Role

logger = logging.getLogger(__name__)


def convert_to_int(num):
    """
    returns None if number is not given, else returns the number in integer format
    """
    if not num:
        return None
    return int(num)


def get_role_objects():
    """
    returns a dict that maps role to role objects present in database
    """
    roles = list(Role.objects.all())
    role_object_map = {role_object.role: role_object for role_object in roles}
    return role_object_map


def get_policy_attribute_type_objects():
    """
    returns a dict that maps attribute name to policy attribute type objects present in database
    """
    policy_attribute_types = list(PolicyAttributeType.objects.all())
    policy_attribute_type_object_map = {policy_attribute_type_object.attribute_name: policy_attribute_type_object for policy_attribute_type_object in policy_attribute_types}
    return policy_attribute_type_object_map


def bulk_create_users(users_data):
    """
    bulk creates users in the database from the given data
    """
    role_object_map = get_role_objects()
    for user_data in users_data:
        user_data['role'] = role_object_map[user_data['role']]
    user_objects = []
    for user_data in users_data:
        user_object = User(
            username=user_data['username'],
            email=user_data['email'],
            role=user_data['role']
        )
        user_object.set_password(user_data['password'])
        user_objects.append(user_object)
    User.objects.bulk_create(user_objects)
    logger.info(f'{len(user_objects)} Users added to the database')


def bulk_create_policy_attribute_type(policy_attribute_type_data):
    """
    bulk creates policy attribute type in the database from the given data
    """
    policy_attribute_type_objects = [
        PolicyAttributeType(
            attribute_name=policy_attribute_type_data_point['attribute_name'],
            attribute_type=policy_attribute_type_data_point['attribute_type'],
            display_metric=policy_attribute_type_data_point['display_metric']
        )
        for policy_attribute_type_data_point in policy_attribute_type_data
    ]
    PolicyAttributeType.objects.bulk_create(policy_attribute_type_objects)
    logger.info(f'{len(policy_attribute_type_objects)} Policy Attribute Types added to the database')


def bulk_create_account(accounts_data):
    """
    bulk creates account in the database from the given data
    """
    account_objects = [
        Account(
            account_name=account_data['account_name'],
            org=Organization.objects.filter(org_name=account_data['org_name']).first(),
            contact=Contact.objects.filter(org__org_name=account_data['org_name']).first()
        )
        for account_data in accounts_data
    ]
    Account.objects.bulk_create(account_objects)
    logger.info(f'{len(account_objects)} Accounts added to the database')


def bulk_create_organization(organizations_data):
    """
    bulk creates organization in the database from the given data
    """
    organization_objects = [
        Organization(
            org_name=organization_data['org_name']
        )
        for organization_data in organizations_data
    ]
    Organization.objects.bulk_create(organization_objects)
    logger.info(f'{len(organization_objects)} Organizations added to the database')


def bulk_create_contact(contacts_data):
    """
    bulk creates contact in the database from the given data
    """
    contact_objects = [
        Contact(
            org=Organization.objects.filter(org_name=contact_data['org_name']).first(),
            contact_type=contact_data['contact_type'],
            phone=contact_data['phone'],
            address=contact_data['address'],
            email=contact_data['email']
        )
        for contact_data in contacts_data
    ]
    Contact.objects.bulk_create(contact_objects)
    logger.info(f'{len(contact_objects)} Contacts added to the database')


def bulk_create_policy(policies_data):
    """
    bulk creates policy in the database from the given data
    """
    for policy_data in policies_data:
        policy_object = Policy(
            policy_name=policy_data['policy_name'],
            policy_type=policy_data['policy_type'],
            coverage_layer=policy_data['coverage_layer'],
            carrier_name=policy_data['carrier_name'],
            account=Account.objects.filter(account_name=dummy_account_name).first()
        )
        policy_object.save()
    logger.info(f'{len(policies_data)} Policies added to the database')


def bulk_create_policy_attribute(policy_attributes_data):
    """
    bulk creates policy attribute in the database from the given data
    """
    policy_attribute_objects = [
        PolicyAttribute(
            policy=policy_attribute_data['policy_name'],
            attr_type=policy_attribute_data['attr_type'],
            number=convert_to_int(policy_attribute_data['number']),
            text=policy_attribute_data['text'],
            date=policy_attribute_data['date']
        )
        for policy_attribute_data in policy_attributes_data
    ]
    PolicyAttribute.objects.bulk_create(policy_attribute_objects)
    logger.info(f'{len(policy_attribute_objects)} Policy Attributes added to the database')


def populate_policy_attribute_type_table():
    """
    populates policy attribute type table
    """
    filter_policy_attributes_to_be_created = [policy_attribute_type for policy_attribute_type in policy_attribute_types
                                              if not PolicyAttributeType.objects.filter(
            attribute_name=policy_attribute_type['attribute_name']).exists()]
    if filter_policy_attributes_to_be_created:
        bulk_create_policy_attribute_type(filter_policy_attributes_to_be_created)
    else:
        logger.info('No Policy Attribute Type needs to be added to the database')


def get_policy_data(worksheet):
    """
    gets policy data from given worksheet
    """
    rows = worksheet.max_row
    columns = worksheet.max_column
    # column_numbers contains a list of integers
    # i.e. actual column numbers that is needed for uploading into policy table
    column_numbers = [column for column in range(1, columns + 1) if
                      worksheet.cell(1, column).value and worksheet.cell(1,
                                                                         column).value.strip() in policy_column_names]
    data = list()
    # iterating through the rows to generate the dicts for the data
    for row in range(2, rows + 1):
        row_data = dict()
        # validate row
        correct_row_data = True
        for column in column_numbers:
            key = worksheet.cell(1, column).value
            value = worksheet.cell(row, column).value
            if key != 'Coverage Layer' and not value:
                correct_row_data = False
                break
            if key == 'Policy Number':
                key = 'policy_name'
            elif key == 'Issuing Carrier':
                key = 'carrier_name'
            elif key == 'Policy Type':
                key = 'policy_type'
                value = value.upper()
            elif key == 'Coverage Layer':
                key = 'coverage_layer'
                value = None if not value else value.upper()
            if key in policy_column_names_database:
                row_data[key] = value
        # updating if row data is correct or not based on keys present in the dict (row_data)
        # and wrong entry in coverage layer
        # i.e. coverage layer can be null only if policy type is property
        if correct_row_data and (not all(
                policy_column_name_database in row_data for policy_column_name_database in policy_column_names_database)
                or (not row_data['coverage_layer'] and row_data['policy_type'] == PolicyType.CASUALTY)
                or (row_data['coverage_layer'] and row_data['policy_type'] == PolicyType.PROPERTY)):
            correct_row_data = False
        if correct_row_data:
            data.append(row_data)
    return data


def get_policy_attribute_data(worksheet):
    """
    gets policy attribute data from given worksheet
    """
    rows = worksheet.max_row
    columns = worksheet.max_column
    required_policy_attributes = [policy_attribute_type['attribute_name'] for policy_attribute_type in
                                  policy_attribute_types]
    column_numbers = [column for column in range(1, columns + 1) if
                      worksheet.cell(1, column).value in required_policy_attributes]
    policy_name_column_number = [column for column in range(1, columns + 1) if
                                 worksheet.cell(1, column).value and worksheet.cell(1,
                                                                                    column).value.strip() == 'Policy Number'][0]
    policy_attribute_type_object_map = get_policy_attribute_type_objects()
    data = list()
    for row in range(2, rows + 1):
        policy_object = Policy.objects.filter(policy_name=worksheet.cell(row, policy_name_column_number).value).first()
        for column in column_numbers:
            header = worksheet.cell(1, column).value
            if header:
                header = header.strip()
            value = worksheet.cell(row, column).value
            if value and isinstance(value, str):
                value = value.strip()
            elif not value:
                continue
            policy_attribute_data = dict()
            policy_attribute_data['policy_name'] = policy_object
            policy_attribute_data['attr_type'] = policy_attribute_type_object_map[header]
            policy_attribute_data['number'] = None
            policy_attribute_data['text'] = None
            policy_attribute_data['date'] = None
            policy_attribute_data[policy_attribute_type_object_map[header].attribute_type.lower()] = value
            if not policy_attribute_data['policy_name'] or not policy_attribute_data['attr_type']:
                break
            data.append(policy_attribute_data)
    return data


def fetch_policy_data_csv(data):
    """
    fetches policy data from the given data that was read from the csv file
    """
    policy_data = list()
    for policy in data:
        policy_dict = dict()
        correct_row_data = True
        for policy_column_name_database, policy_column_name in zip(policy_column_names_database, policy_column_names):
            key = policy_column_name_database
            value = policy[policy_column_name]
            if key != 'coverage_layer' and not value:
                correct_row_data = False
                break
            if key == 'policy_type':
                value = value.upper()
            elif key == 'coverage_layer':
                value = None if not value else value.upper()
            policy_dict[key] = value
        if correct_row_data and policy_dict:
            policy_data.append(policy_dict)
    return policy_data


def fetch_policy_attribute_csv(data):
    """
    fetches policy data from the given data that was read from the csv file
    """
    required_policy_attributes = [policy_attribute_type['attribute_name'] for policy_attribute_type in
                                  policy_attribute_types]
    policy_attribute_type_object_map = get_policy_attribute_type_objects()
    policy_attribute_data = list()
    for policy_attribute in data:
        policy_object = Policy.objects.filter(policy_name=policy_attribute['Policy Number']).first()
        for key, value in policy_attribute.items():
            if key and key in required_policy_attributes:
                key = key.strip()
            else:
                continue
            if value and isinstance(value, str):
                value = value.strip()
            elif not value:
                continue
            policy_attribute_dict = dict()
            policy_attribute_dict['policy_name'] = policy_object
            policy_attribute_dict['attr_type'] = policy_attribute_type_object_map[key]
            policy_attribute_dict['number'] = None
            policy_attribute_dict['text'] = None
            policy_attribute_dict['date'] = None
            if policy_attribute_type_object_map[key].attribute_type.lower() == 'date':
                value = datetime.strptime(value, '%m/%d/%Y')
            policy_attribute_dict[policy_attribute_type_object_map[key].attribute_type.lower()] = value
            if not policy_attribute_dict['policy_name'] or not policy_attribute_dict['attr_type']:
                break
            policy_attribute_data.append(policy_attribute_dict)
    return policy_attribute_data


def handle_csv_file_path(file_path):
    """
    reads csv file present in the given file path, extracts data and populates it into the database
    """
    data = list()
    with open(file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data.append(row)
    populate_policy_attribute_type_table()
    policy_data = fetch_policy_data_csv(data)
    bulk_create_policy(policy_data)
    policy_attribute_data = fetch_policy_attribute_csv(data)
    bulk_create_policy_attribute(policy_attribute_data)


def handle_excel_file_path(file_path):
    """
    reads excel file present in the given file path, extracts data and populates it into the database
    """
    workbook = load_workbook(file_path)
    worksheet = workbook.active
    populate_policy_attribute_type_table()
    policy_data = get_policy_data(worksheet)
    bulk_create_policy(policy_data)
    policy_attribute_data = get_policy_attribute_data(worksheet)
    bulk_create_policy_attribute(policy_attribute_data)


def handle_uploaded_file(file_obj):
    """
    takes file object as input, reads the data present in it and uploads the data into the database
    """
    date_time = datetime.now().strftime('%s')
    dot_pos = file_obj.name.rfind('.')
    file_name = file_obj.name[:dot_pos] + '_' + date_time + file_obj.name[dot_pos:]
    path = default_storage.save(file_name, file_obj)
    logger.info(f"File uploaded to {MEDIA_ROOT}{path}")
    uploaded_file_type = file_obj.content_type
    logger.info(f"File Type: {uploaded_file_type}")
    if uploaded_file_type == 'text/csv':
        handle_csv_file_path(MEDIA_ROOT + path)
    elif uploaded_file_type in ['application/vnd.ms-excel',
                                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']:
        handle_excel_file_path(MEDIA_ROOT + path)
