from rest_framework.test import APITestCase
from rest_framework import status

from canvas.constants import dummy_account_name
from canvas.settings import MEDIA_ROOT
from canvas.utils import handle_excel_file_path
from core.constants import ContactType
from core.models import Organization, Contact, Account, Policy


class DataUploadTests(APITestCase):
    def setUp(self):
        self.org = Organization(org_name='Walmart')
        self.org.save()
        self.contact = Contact(
            org=self.org,
            contact_type=ContactType.PRIMARY,
            phone='9123456789',
            address='Brooklyn',
            email='walmart@gmail.com'
        )
        self.contact.save()
        self.account = Account(account_name=dummy_account_name, org=self.org, contact=self.contact)
        self.account.save()

    def test_handle_excel_file_path(self):
        """
        Ensure we can upload data to the database using excel file
        """
        file_path = MEDIA_ROOT + 'Upload_Data_Test_1.xlsx'
        handle_excel_file_path(file_path)
        policies_created = Policy.objects.all().count()
        policy_1_exists = Policy.objects.filter(policy_name='POL101').exists()
        policy_2_exists = Policy.objects.filter(policy_name='POL104').exists()
        self.assertEqual(policies_created, 6)
        self.assertEqual(policy_1_exists, True)
        self.assertEqual(policy_2_exists, True)

    def test_handle_excel_file_path_missing_policy_type(self):
        """
        Ensure we can upload data to the database using excel file with missing policy type
        """
        file_path = MEDIA_ROOT + 'Upload_Data_Test_2.xlsx'
        handle_excel_file_path(file_path)
        policies_created = Policy.objects.all().count()
        policy_1_exists = Policy.objects.filter(policy_name='POL101').exists()
        policy_2_exists = Policy.objects.filter(policy_name='POL104').exists()
        self.assertEqual(policies_created, 2)
        self.assertEqual(policy_1_exists, False)
        self.assertEqual(policy_2_exists, False)

    def test_handle_excel_file_path_missing_coverage_layer(self):
        """
        Ensure we can upload data to the database using excel file with missing coverage layer
        """
        file_path = MEDIA_ROOT + 'Upload_Data_Test_3.xlsx'
        handle_excel_file_path(file_path)
        policies_created = Policy.objects.all().count()
        policy_1_exists = Policy.objects.filter(policy_name='POL101').exists()
        policy_2_exists = Policy.objects.filter(policy_name='POL104').exists()
        self.assertEqual(policies_created, 3)
        self.assertEqual(policy_1_exists, False)
        self.assertEqual(policy_2_exists, True)

