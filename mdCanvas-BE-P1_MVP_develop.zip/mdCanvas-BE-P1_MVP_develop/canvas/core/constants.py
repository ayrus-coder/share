from django.db import models
from django.utils.translation import gettext_lazy as _


class ContactType(models.TextChoices):
    PRIMARY = 'PRIMARY', _('Primary')
    SECONDARY = 'SECONDARY', _('Secondary')


class CoverageLayer(models.TextChoices):
    UMBRELLA = 'UMBRELLA', _('Umbrella')
    PRIMARY = 'PRIMARY', _('Primary')
    BUFFER = 'BUFFER', _('Buffer')
    EXCESS = 'EXCESS', _('Excess')


class PolicyType(models.TextChoices):
    CASUALTY = 'CASUALTY', _('Casualty')
    PROPERTY = 'PROPERTY', _('Property')
    PROPERTY_AND_CASUALTY = 'PROPERTY & CASUALTY', _('Property and Casualty')


class AttributeType(models.TextChoices):
    NUMBER = 'NUMBER', _('Number')
    TEXT = 'TEXT', _('Text')
    DATE = 'DATE', _('Date')
    JSON = 'JSON', _('Json')


class DisplayMetric(models.TextChoices):
    MILL = 'M', _('Million')
    THOUSAND = 'TH', _('Thousand')
    CURR = 'CURR', _('Currency')
    SYMB = 'SYMB', _('Symbol')
    TEXT = 'TEXT', _('Text')
    CSV = 'CSV', _('CSV')
    PERCENTAGE = 'PERCENTAGE', _('Percentage')

