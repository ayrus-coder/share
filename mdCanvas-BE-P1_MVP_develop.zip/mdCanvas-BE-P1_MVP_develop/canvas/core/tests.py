from django.test import TestCase
from django.urls import reverse
from login.constants import UserType
from core.models import Account, Organization, Contact, Broker, Policy, PolicyAttribute, PolicyAttributeType
from login.models import User, Role
from core.constants import PolicyType, CoverageLayer
from canvas.utils import populate_policy_attribute_type_table
from rest_framework.test import APIClient
from rest_framework import status
# Create your tests here.

class CoreTestCase(TestCase):

    custom_client = APIClient()

    def setUp(self) -> None:
        self.org_1 = Organization.objects.create(org_name="org_1")
        self.contact_1 = Contact.objects.create(
            org = self.org_1,
            phone = '123456',
            address = '#12, 1st street, some road, city',
            email='test@org1.com'
        )
        self.contact_2 = Contact.objects.create(
            org = self.org_1,
            phone = '12345678',
            address = '#128, 17st street, some road, city',
            email='test@org1.com'
        )
        self.RM_role = Role.objects.create(role=UserType.RISK_MANAGER)
        self.BR_role = Role.objects.create(role=UserType.BROKER)
        self.user_1 = User.objects.create(
            username='user_1',
            email='user_1@org1.com',
            password='user1@org1',
            role= self.BR_role
        )
        self.user_2 = User.objects.create(
            username='user_2',
            email='user_2@org1.com',
            password='user2@org1',
            role= self.BR_role
        )
        self.user_3 = User.objects.create(
            username='user_3',
            email='user_3@org1.com',
            password='user3@org1',
            role= self.RM_role
        )
        self.account_1 = Account.objects.create(
            account_name='acc_1',
            org = self.org_1,
            contact = self.contact_1
        )

        self.account_2 = Account.objects.create(
            account_name='acc_2',
            org = self.org_1,
            contact = self.contact_1
        )
        self.account_3 = Account.objects.create(
            account_name='acc_3',
            org = self.org_1,
            contact = self.contact_1
        )
        self.broker_1 = Broker.objects.create(
            account=self.account_1,
            org=self.org_1,
            user=self.user_1
        )
        self.broker_2 = Broker.objects.create(
            account=self.account_2,
            org=self.org_1,
            user=self.user_1
        )
        self.broker_3 = Broker.objects.create(
            account=self.account_2,
            org=self.org_1,
            user=self.user_2
        )

        self.policy_1 = Policy.objects.create(
            policy_name="POL101",
            carrier_name="C1",
            account = self.account_1
        )

        self.policy_2 = Policy.objects.create(
            policy_name="POL102",
            carrier_name="C1",
            account = self.account_1
        )

        self.policy_3 = Policy.objects.create(
            policy_name="POL103",
            carrier_name="C1",
            account = self.account_2,
            policy_type = PolicyType.CASUALTY,
            coverage_layer = CoverageLayer.PRIMARY
        )

        populate_policy_attribute_type_table()

        self.policy_attr_1 = PolicyAttribute.objects.create(
            policy = self.policy_1,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'First Named Insured'),
            text='Insurance1'
        )

        self.policy_attr_2 = PolicyAttribute.objects.create(
            policy = self.policy_1,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'Policy Name'),
            text='POL101'
        )

        self.policy_attr_3 = PolicyAttribute.objects.create(
            policy = self.policy_1,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'Attachment Point'),
            number=0
        )

        self.policy_attr_4 = PolicyAttribute.objects.create(
            policy = self.policy_2,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'First Named Insured'),
            text='Insurance2'
        )

        self.policy_attr_5 = PolicyAttribute.objects.create(
            policy = self.policy_2,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'Policy Name'),
            text='POL102'
        )

        self.policy_attr_6 = PolicyAttribute.objects.create(
            policy = self.policy_2,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'Attachment Point'),
            number=10
        )

        self.policy_attr_7 = PolicyAttribute.objects.create(
            policy = self.policy_3,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'First Named Insured'),
            text='Insurance1'
        )

        self.policy_attr_8 = PolicyAttribute.objects.create(
            policy = self.policy_3,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'Policy Name'),
            text='POL103'
        )

        self.policy_attr_9 = PolicyAttribute.objects.create(
            policy = self.policy_3,
            attr_type = PolicyAttributeType.objects.get(attribute_name = 'Attachment Point'),
            number=100
        )



    def return_access_token(self,credential_data):
        login_url = reverse('token_obtain_pair')
        login_response = self.custom_client.post(login_url,credential_data,format='json')
        token = login_response.data['data']['access_token']
        return token

    def get_response(self, username, password, url):
        data = {
            'username':username,
            'password':password
        }
        token = self.return_access_token(credential_data=data)
        self.custom_client.credentials(HTTP_AUTHORIZATION='Bearer '+ token)
        response = self.custom_client.get(url,format='json')
        return response

    def test_getting_accounts_for_broker(self):
        """
        Testing fetching of accounts for brokers
        """
        account_url = reverse('account-list')
        response = self.get_response(username=self.user_1.username, password='user1@org1', url=account_url)
        self.assertEqual(len(response.data),2)
        self.assertEqual(response.data[0]['id'], str(self.account_1.id))
        self.assertEqual(response.data[1]['id'], str(self.account_2.id))

    def test_getting_accounts_for_non_brokers(self):
        """
        Testing fetching of accounts for non brokers
        """
        # Non brokers cannot access the policy details page, therefore they cannot access the account drop down API's
        account_url = reverse('account-list')
        response = self.get_response(username=self.user_3.username,password='user3@org1',url=account_url)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_getting_total_policy_details(self):
        """
        Testing getting total policy details
        """
        policy_url = reverse('policy-list')
        response = self.get_response(username=self.user_1.username, password='user1@org1', url=policy_url)
        data = response.data
        self.assertEqual(len(data),3)

    def test_getting_policy_details_for_an_account(self):
        """
        Testing getting the policy linked to particular account
        """
        policy_url = f"{reverse('policy-list')}?account__id={self.account_1.id}"
        response = self.get_response(username=self.user_1.username, password='user1@org1', url=policy_url)
        data = response.data
        self.assertEqual(len(data),2)
        policy_names = [item['policy_name'] for item in data]
        self.assertTrue(self.policy_1.policy_name in policy_names)
        self.assertTrue(self.policy_2.policy_name in policy_names)
        self.assertFalse(self.policy_3.policy_name in policy_names)

    def test_checking_attribute_data_in_policy_object(self):
        """
        Testing if the attribute data is correctly being returned
        """
        policy_url = f"{reverse('policy-list')}?account__id={self.account_2.id}"
        response = self.get_response(username=self.user_1.username, password='user1@org1', url=policy_url)
        data = response.data
        attribute_data = data[0]['attributes']
        self.assertEqual(len(data),1)
        self.assertEqual(len(attribute_data),30)
        attribute_map_dict = {item['attribute_name']:item for item in attribute_data}
        self.assertEqual(attribute_map_dict['First Named Insured']['value'], self.policy_attr_7.text)
        self.assertEqual(attribute_map_dict['Policy Name']['value'], self.policy_attr_8.text)
        self.assertEqual(attribute_map_dict['Attachment Point']['value'], self.policy_attr_9.number)