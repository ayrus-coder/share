import uuid
from django_unixdatetimefield import UnixDateTimeField
from django.db import models
from login.models import User
from core.constants import ContactType, PolicyType, CoverageLayer, AttributeType, DisplayMetric


class TimestampModel(models.Model):
    created_at = UnixDateTimeField(auto_now_add=True)
    updated_at = UnixDateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Organization(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    org_name = models.CharField(max_length=280)

    def __str__(self) -> str:
        return f"{self.org_name}"
    class Meta:
        db_table = 'MD_ORG'


class Contact(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    org = models.ForeignKey(Organization, on_delete=models.DO_NOTHING, related_name="contacts", null=False)
    contact_type = models.CharField(max_length=20, choices=ContactType.choices, default=ContactType.PRIMARY, null=False)
    phone = models.CharField(max_length=12, null=False)
    address = models.CharField(max_length=700, null=False)
    email = models.EmailField(max_length=120, null=False)

    def __str__(self) -> str:
        return f"{self.org.org_name} - {self.phone} - {self.email}"
    class Meta:
        db_table = 'MD_CONTACT'


class Account(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    account_name = models.CharField(max_length=250, null=False)
    org = models.ForeignKey(Organization, on_delete=models.DO_NOTHING, null=False)
    contact = models.ForeignKey(Contact, on_delete=models.DO_NOTHING, null=False)


    class Meta:
        db_table = 'MD_ACCOUNT'

    def __str__(self):
        return f'{self.account_name} - {str(self.org)}'


class Broker(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    account = models.ForeignKey(Account, on_delete=models.DO_NOTHING, null=False)
    org = models.ForeignKey(Organization, on_delete=models.DO_NOTHING, null=True, blank=True)
    contact = models.OneToOneField(Contact, on_delete=models.DO_NOTHING, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, null=False)

    def __str__(self) -> str:
        return f"{self.user.username} - {self.account.account_name}"
    class Meta:
        db_table = 'MD_USR_BRK'



class RiskManager(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    account = models.ForeignKey(Account, on_delete=models.DO_NOTHING, null=False)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, null=False)

    def __str__(self) -> str:
        return f"{self.account.account_name} - {self.user.username}"
    class Meta:
        db_table = 'MD_USR_RM'



class Program(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    program_name = models.CharField(max_length=250, null=False)
    account = models.ForeignKey(Account, on_delete=models.DO_NOTHING, null=False)

    def __str__(self) -> str:
        return f"{self.program_name}"
    class Meta:
        db_table = 'MD_PROGRAM'



class Policy(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    policy_name = models.CharField(max_length=250, null=False)
    policy_version_nbr = models.IntegerField(default=0)
    policy_type = models.CharField(max_length=20, choices=PolicyType.choices, default=PolicyType.PROPERTY, null=False)
    coverage_layer = models.CharField(max_length=20, choices=CoverageLayer.choices, null=True, blank=True)
    carrier_name = models.CharField(max_length=250, null=False)
    account = models.ForeignKey(Account, on_delete=models.DO_NOTHING, null=False)
    active = models.BooleanField(default=True, null=False)

    def save(self, *args, **kwargs):
        if not Policy.objects.filter(policy_name=self.policy_name).exists():
            self.policy_version_nbr = 1
        else:
            self.policy_version_nbr = self.policy_version_nbr + 1
        super(Policy, self).save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.policy_name}"
    class Meta:
        db_table = 'MD_POLICIES'


class ProgramPolicyMap(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    program = models.ForeignKey(Program, on_delete=models.DO_NOTHING, null=False)
    policy = models.ForeignKey(Policy, on_delete=models.DO_NOTHING, null=False)

    class Meta:
        db_table = 'MD_PRG_POLICY_MAP'

    def __str__(self):
        return f'{str(self.program)} - {str(self.policy)}'


class PolicyAttributeType(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    attribute_name = models.CharField(max_length=250, null=False)
    active = models.BooleanField(default=True, null=False)
    attribute_type = models.CharField(max_length=20, choices=AttributeType.choices, default=AttributeType.NUMBER, null=False)
    display_metric = models.CharField(max_length=20, choices=DisplayMetric.choices, default=DisplayMetric.CURR, null=False)

    def __str__(self) -> str:
        return f"{self.attribute_name}"
    class Meta:
        db_table = 'MD_POL_ATTR_TYPE'



class PolicyAttribute(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    policy = models.ForeignKey(Policy, on_delete=models.DO_NOTHING, null=False)
    attr_type = models.ForeignKey(PolicyAttributeType, on_delete=models.DO_NOTHING, null=False)
    number = models.BigIntegerField(null=True, blank=True)
    text = models.CharField(max_length=500, null=True, blank=True)
    date = models.DateTimeField(null=True, blank=True)

    def __str__(self) -> str:
        return f"{self.policy.policy_name}-{self.attr_type.attribute_name}"
    class Meta:
        db_table = 'MD_POL_ATTR'



class Data(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=250, null=False)
    version = models.IntegerField(default=0)
    policy_mapping = models.JSONField(null=False)
    location = models.CharField(max_length=500, null=False)
    account = models.ForeignKey(Account, on_delete=models.DO_NOTHING, null=False)
    broker = models.ForeignKey(Broker, on_delete=models.DO_NOTHING, null=False)
    program = models.ForeignKey(Program, on_delete=models.DO_NOTHING, null=False)
    effective_date = models.DateTimeField(null=False, blank=False)
    expiration_date = models.DateTimeField(null=False, blank=False)
    policy_type = models.CharField(max_length=20, choices=PolicyType.choices, default=PolicyType.PROPERTY, null=False)

    def save(self, *args, **kwargs):
        if not Data.objects.filter(name=self.name).exists():
            self.version = 1
        else:
            self.version = self.version + 1
        super(Data, self).save(*args, **kwargs)

    class Meta:
        db_table = 'MD_DATA'

    def __str__(self):
        return self.name


class RiskManagerDataMap(TimestampModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    risk_manager = models.ForeignKey(RiskManager, on_delete=models.DO_NOTHING, null=False)
    favourite = models.BooleanField(default=False, null=False)
    data = models.ForeignKey(Data, on_delete=models.DO_NOTHING, null=False)

    class Meta:
        db_table = 'MD_RM_DATA_MAP'

    def __str__(self):
        return f'{str(self.risk_manager)} - {str(self.data)}'
