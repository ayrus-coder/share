import logging
from rest_framework import permissions
from login.constants import UserType

logger = logging.getLogger(__name__)
class IsBroker(permissions.BasePermission):
    """
    Permission class to allow only users with broker roles
    """
    def has_permission(self, request, view):
        try:
            if request.user.is_authenticated and request.user.role.role == UserType.BROKER:
                return True
            else:
                return False
        except Exception as e:
            logger.exception("Exception occured when trying to validate the request user was a broker")
            return False