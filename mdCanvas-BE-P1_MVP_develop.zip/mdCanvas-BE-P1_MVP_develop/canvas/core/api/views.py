from rest_framework import viewsets
from canvas.renderers import CustomRenderer
from core.permissions import IsBroker
from core.api.serializers import GetAccountNameSerializer, PolicyDataSerializer
from core.models import Account, Policy
from django_filters import rest_framework as filters
class AccountViewSet(viewsets.ReadOnlyModelViewSet):
    """
    A simple ViewSet for getting account details.
    """
    serializer_class = GetAccountNameSerializer
    permission_classes = [IsBroker]
    renderer_classes = [CustomRenderer]

    # Filtering accounts based on the logged in user - broker. 
    def get_queryset(self):
        account_ids = self.request.user.broker_set.values_list('account_id')
        return Account.objects.filter(id__in=account_ids)

class PolicyDataViewSet(viewsets.ReadOnlyModelViewSet):
    """
    A simple ViewSet for getting Policy details.
    """
    queryset = Policy.objects.all()
    serializer_class = PolicyDataSerializer
    permission_classes = [IsBroker]
    renderer_classes = [CustomRenderer]
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_fields = ('account__id',)