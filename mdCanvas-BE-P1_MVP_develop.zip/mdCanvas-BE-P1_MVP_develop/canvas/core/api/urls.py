from django.urls import path, include
from rest_framework.routers import DefaultRouter
from core.api.views import AccountViewSet, PolicyDataViewSet

# Create a router and register our viewsets with it.
router = DefaultRouter()
router.register(r'accounts',AccountViewSet, basename='account')
router.register(r'policy',PolicyDataViewSet, basename='policy')
urlpatterns = [
    path('', include(router.urls))
]