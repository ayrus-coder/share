from dataclasses import field
from rest_framework import serializers

from core.models import Account, Policy, PolicyAttribute, PolicyAttributeType
from core.constants import AttributeType as attribute_type_choices
from canvas.constants import policy_attribute_types as list_of_policy_attribute_types
class GetAccountNameSerializer(serializers.ModelSerializer):
    """
    Serializer to get account name and id.
    """
    class Meta:
        model = Account
        fields = ['id','account_name'] 

class PolicyAttributeTypeSerializer(serializers.ModelSerializer):
    """
    Serializer to get Policy Attribute Type data
    """
    class Meta:
        model = PolicyAttributeType
        fields = ['attribute_name','attribute_type','display_metric']


class PolicyAttributeSerializer(serializers.ModelSerializer):
    """
    Serializer to get Policy Attribute details
    """
    attr_type = PolicyAttributeTypeSerializer(read_only=True)
    class Meta:
        model = PolicyAttribute
        fields = ['id','number','text','date','attr_type']
    
    def to_representation(self, instance):
        # modifying the way the policy attribute type data is returned,
        # instead of policy attribute type being in a seperate dictionary, we are populating it in policy attribute serializer dictionary
        # so that the data returned is one dictionary instead of nested dictionaries.
        data = super().to_representation(instance)
        attribute_type = data.pop('attr_type',None)
        # instead of having 3 fields 'text','number','date' we will just have 1 field called value
        if attribute_type['attribute_type'] == attribute_type_choices.NUMBER:
            data.pop('text')
            data.pop('date')
            data['value'] = data.pop('number')
        elif attribute_type['attribute_type'] == attribute_type_choices.TEXT:
            data.pop('number')
            data.pop('date')
            data['value'] = data.pop('text')
        elif attribute_type['attribute_type'] == attribute_type_choices.DATE:
            data.pop('text')
            data.pop('number')
            data['value'] = data.pop('date')
        data.update(attribute_type)
        return data


class PolicyDataSerializer(serializers.ModelSerializer):
    """
    Serializer for policy details
    """
    attributes = PolicyAttributeSerializer(many=True, read_only=True,source='policyattribute_set')
    account = GetAccountNameSerializer(read_only=True)
    class Meta:
        model = Policy
        fields = ['id','policy_name','policy_version_nbr','policy_type','coverage_layer','carrier_name','account','attributes']

    def to_representation(self, instance):
        # This is to create any missing attributes data for a policy object with values as null
        data = super().to_representation(instance)
        new_attribute_list = []
        attribute_list = data.pop('attributes', None)
        # Dictionary Mapping of attribute name to attribute object , used for lookup of attribute names
        attribute_name_to_attribute_map = {item['attribute_name']:item for item in attribute_list}
        # Iterates through constant list of policy attribute types and creates the attributes array for a policy object
        for attribute_item in list_of_policy_attribute_types:
            # checks if the attribute object is present in the database, if not creates the attributes object with values as null (except for carrier and coverage_layer)
            if attribute_item['attribute_name'] in attribute_name_to_attribute_map:
                values_dict = attribute_name_to_attribute_map[attribute_item['attribute_name']]
                new_attribute_list.append(values_dict)
            else:
                values_dict = {}
                values_dict['id'] = None
                values_dict['value'] = None
                if attribute_item['attribute_name'] == "Carrier":
                    values_dict['value'] = data.get('carrier_name', None)
                elif attribute_item['attribute_name'] == "Coverage Layer":
                    values_dict['value'] = data.get('coverage_layer', None)
                values_dict.update(attribute_item)
                new_attribute_list.append(values_dict)
        data['attributes'] = new_attribute_list
        return data