from django.contrib import admin
from core.models import Organization, Contact, Account, Broker, RiskManager, Program, Policy, ProgramPolicyMap, PolicyAttributeType, PolicyAttribute, Data, RiskManagerDataMap

admin.site.register(Organization)
admin.site.register(Contact)
admin.site.register(Account)
admin.site.register(Broker)
admin.site.register(RiskManager)
admin.site.register(Program)
admin.site.register(Policy)
admin.site.register(ProgramPolicyMap)
admin.site.register(PolicyAttributeType)
admin.site.register(PolicyAttribute)
admin.site.register(Data)
admin.site.register(RiskManagerDataMap)
